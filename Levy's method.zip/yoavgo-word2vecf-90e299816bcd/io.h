void ReadWord(char *word, FILE *fin, int MAX_STRING);

